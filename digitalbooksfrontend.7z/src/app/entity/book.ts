export default class Book{
    constructor (public title:string, public author:string, public category:string, public price:number, public publisher:string, public date:string ){}
}