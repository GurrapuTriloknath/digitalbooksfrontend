// import { NgModule } from '@angular/core';
// import { RouterModule, Routes } from '@angular/router';

// const routes: Routes = [];

// @NgModule({
//   imports: [RouterModule.forRoot(routes)],
//   exports: [RouterModule]
// })
// export class AppRoutingModule { }

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BookslistComponent } from './bookslist/bookslist.component';
import { CreatebookComponent } from './createbook/createbook.component';



const routes: Routes = [
  
  { path:'createbook', component: CreatebookComponent },
  {
    path:'',redirectTo:'/createbook' , pathMatch:'full'
  },
  { path:'createbook', component: CreatebookComponent},
  { path:'bookslist', component: BookslistComponent}
]



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }