import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import Book from '../entity/book';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.scss']
})
export class BookformComponent implements OnInit{
 book:Book=new Book('virat','rizz','cricket',500,'BCCI','2000-02-01');
 
 constructor(public bookService:BookService) { }
 ngOnInit(): void {
  
}
 
 save(){
  console.log ('clicked');
  const observable = this.bookService.saveUser(this.book);
  observable.subscribe((response)=>{ 
    console.log(response);
  })
}
}
