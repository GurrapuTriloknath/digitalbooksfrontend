import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import Book from './entity/book';
const API_URL="http://localhost:8099/books/"

@Injectable({
  providedIn: 'root'
})
export class BookService {
 
 constructor(public client:HttpClient) { }
 //DeleteUser
 deleteBook(id: number) {
   return this.client.delete(API_URL + id);
 }
 //ngonit method
 getBooks(){
   return this.client.get(API_URL);
 }
  saveUser(book: Book) {
   return this.client.post(API_URL, book)
         }
    }