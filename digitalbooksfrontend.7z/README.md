1)missing coloring
2)missing design
3)validation pending
4)border lines pending
5)login page pending

